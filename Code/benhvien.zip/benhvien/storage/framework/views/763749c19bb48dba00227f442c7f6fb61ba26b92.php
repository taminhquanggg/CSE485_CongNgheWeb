<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết phiếu xn</title>
</head>
<body>
    <p>MaPhieu: <?php echo $phieuxn->MaPhieu; ?></p>
    <p>MaBN: <?php echo $phieuxn->MaBN; ?></p>
    <p>TenXN: <?php echo $phieuxn->TenXN; ?></p>
    <p>NgayXN: <?php echo $phieuxn->NgayXN; ?></p>
    <p>KetQuaXN: <?php echo $phieuxn->KetQuaXN; ?></p>
    <p>ChiPhi: <?php echo $phieuxn->ChiPhi; ?></p>

    <a href="/phieuxn"><< Quay về</a>
</body>
</html><?php /**PATH E:\project\WebPHP\benhvien\resources\views/phieuxn/detail.blade.php ENDPATH**/ ?>