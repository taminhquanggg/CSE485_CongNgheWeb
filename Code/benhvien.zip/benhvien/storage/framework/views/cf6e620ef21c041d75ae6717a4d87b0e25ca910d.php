<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm bệnh nhân</title>
</head>
<body>
<a href="/">Trang chủ</a>
    <h1>THÊM BỆNH NHÂN</h1>

    <form action="" method="POST">
        <label for="txtMaBN">Mã bệnh nhân</label>
        <input type="text" id="txtMaBN" name="txtMaBN"  readonly>
        <br>
        
        <label for="txtTenBN">Tên bệnh nhân</label>
        <input type="text" id="txtTenBN" name="txtTenBN">
        <br>
        <?php if($errors->has('txtTenBN')): ?>
        <p style = "color: red">Cần nhập tên bệnh nhân</p>
        <?php endif; ?>

        <label for="txtCCCD">CCCD</label>
        <input type="text" id="txtCCCD" name="txtCCCD">
        <br>
        <?php if($errors->has('txtCCCD')): ?>
        <p style = "color: red">Cần nhập CCCD</p>
        <?php endif; ?>

        <label for="txtNgaySinh">Ngày sinh</label>
        <input type="date" id="txtNgaySinh" name="txtNgaySinh">
        <br>
        <?php if($errors->has('txtNgaySinh')): ?>
        <p style = "color: red">Cần nhập Ngày sinh</p>
        <?php endif; ?>

        <label for="txtGioiTinh">Giới tính</label>
        <select name="txtGioiTinh" id="txtGioiTinh">
            <option value="Nam">Nam</option>
            <option value="Nữ">Nữ</option>
        </select>
        <br>
        <?php if($errors->has('txtGioiTinh')): ?>
        <p style = "color: red">Cần nhập Giới tính</p>
        <?php endif; ?>

        <label for="txtQueQuan">Quê quán</label>
        <input type="text" id="txtQueQuan" name="txtQueQuan">
        <br>
        <?php if($errors->has('txtQueQuan')): ?>
        <p style = "color: red">Cần nhập Quê quán</p>
        <?php endif; ?>
        
        <?php echo csrf_field(); ?>
        <button>Thêm</button>
    </form>
</body>
</html><?php /**PATH E:\project\WebPHP\benhvien\resources\views/benhnhan/add.blade.php ENDPATH**/ ?>