<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
</head>
<body>
    <a href="/benhnhan">Quản lý bệnh nhân</a>
    <br>
    <a href="/phieuxn">Quản lý phiếu xn</a>

</body>
</html><?php /**PATH E:\project\WebPHP\benhvien\resources\views/welcome.blade.php ENDPATH**/ ?>