<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết bệnh nhân</title>
</head>
<body>
    <p>MaBN: <?php echo $benhnhan->MaBN; ?></p>
    <p>TenBN: <?php echo $benhnhan->TenBN; ?></p>
    <p>CCCD: <?php echo $benhnhan->CCCD; ?></p>
    <p>NgaySinh: <?php echo $benhnhan->NgaySinh; ?></p>
    <p>GioiTinh: <?php echo $benhnhan->GioiTinh; ?></p>
    <p>QueQuan: <?php echo $benhnhan->QueQuan; ?></p>
    <a href="/benhnhan"><< Quay về</a>
</body>
</html><?php /**PATH E:\project\WebPHP\benhvien\resources\views/benhnhan/detail.blade.php ENDPATH**/ ?>