<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm phiếu xn</title>
</head>
<body>
    <h1>THÊM PHIẾU XN</h1>

    <form action="" method="POST">
        <label for="txtMaPhieu">Mã phiếu</label>
        <input type="text" id="txtMaPhieu" name="txtMaPhieu"  readonly>
        <br>
        
        <label for="txtMaBN">Mã BN</label>
        <select name="txtMaBN" id="txtMaBN">
            <?php $__currentLoopData = $benhnhans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benhnhan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo $benhnhan->MaBN; ?>"><?php echo $benhnhan->MaBN; ?> | <?php echo $benhnhan->TenBN; ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php if($errors->has('txtMaBN')): ?>
        <p style = "color: red">Cần nhập mã BN</p>
        <?php endif; ?>

        <label for="txtTenXN">Tên XN</label>
        <input type="text" id="txtTenXN" name="txtTenXN">
        <br>
        <?php if($errors->has('txtTenXN')): ?>
        <p style = "color: red">Cần nhập tên XN</p>
        <?php endif; ?>

        <label for="txtNgayXN">Ngày XN</label>
        <input type="date" id="txtNgayXN" name="txtNgayXN">
        <br>
        <?php if($errors->has('txtNgayXN')): ?>
        <p style = "color: red">Cần nhập ngày XN</p>
        <?php endif; ?>

        <label for="txtKetQuaXN">Kết quả XN</label>
        <input type="text" id="txtKetQuaXN" name="txtKetQuaXN">
        <br>
        <?php if($errors->has('txtKetQuaXN')): ?>
        <p style = "color: red">Cần nhập kết quả XN</p>
        <?php endif; ?>

        <label for="txtChiPhi">Chi phí</label>
        <input type="text" id="txtChiPhi" name="txtChiPhi">
        <br>
        <?php if($errors->has('txtChiPhi')): ?>
        <p style = "color: red">Cần nhập chi phí</p>
        <?php endif; ?>
        
        <?php echo csrf_field(); ?>
        <button>Thêm</button>
    </form>
</body>
</html><?php /**PATH E:\project\WebPHP\benhvien\resources\views/phieuxn/add.blade.php ENDPATH**/ ?>