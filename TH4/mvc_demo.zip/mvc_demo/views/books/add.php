<h1>
    Thêm mới sách
</h1>

<!--</form>-->
<div style="color: red">
    <?php echo $error; ?>
</div>
<form method="post" action="">
    Name :
    <input type="text" name="name" value="" />
    <br />
    <input type="submit" name="submit" value="Save" />
</form>