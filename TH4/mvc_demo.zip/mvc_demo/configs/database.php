<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 11/14/2019
 * Time: 6:45 PM
 */
//khai báo các hằng số dùng cho kết nối csdl
const DB_HOST = 'localhost';
const DB_USERNAME = 'root';
const DB_PASSWORD = '';
const DB_NAME = 'book_mvc';
