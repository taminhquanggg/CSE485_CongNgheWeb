<?php

// Define DB Params
define("DB_HOST", ""); // ex. localhost
define("DB_USER", "");
define("DB_PASS", "");
define("DB_NAME", "");

// Define URL
define("ROOT_PATH", ""); // https://www.yourdomain.com/ or https://www.yourdomain.com/website/

?>